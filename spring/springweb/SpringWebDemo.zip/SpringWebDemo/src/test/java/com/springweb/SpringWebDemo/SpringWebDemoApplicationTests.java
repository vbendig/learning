package com.springweb.SpringWebDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
